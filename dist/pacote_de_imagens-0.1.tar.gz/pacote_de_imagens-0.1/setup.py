from setuptools import setup, find_packages

setup(
    name='pacote_de_imagens',  # Nome do pacote deve estar em minúsculas e usar underscores
    version='0.1',
    packages=find_packages(),
    install_requires=[
        # Adicione suas dependências aqui, se houver
    ],
)
